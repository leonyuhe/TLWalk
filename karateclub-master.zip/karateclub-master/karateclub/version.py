"""Contains the version of Karate Club."""

__version__ = "1.3.4"
